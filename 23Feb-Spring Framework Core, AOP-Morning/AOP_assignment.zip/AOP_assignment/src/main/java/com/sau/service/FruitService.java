package com.sau.service;

import com.sau.model.England;
import com.sau.model.India;

public class FruitService {

	private India india;
	private England england;

	public India getIndia() {
		return india;
	}

	public void setIndia(India india) {
		this.india = india;
	}

	public England getEngland() {
		return england;
	}

	public void setEngland(England england) {
		this.england = england;
	}
}
