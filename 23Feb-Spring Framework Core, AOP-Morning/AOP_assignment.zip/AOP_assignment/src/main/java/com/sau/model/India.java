package com.sau.model;

public class India {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		System.out.println("After setting name to INDIA object");
	}

}
